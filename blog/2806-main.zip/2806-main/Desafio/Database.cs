using Microsoft.Data.SqlClient;

namespace Blog
{
    public static class Database
    {
        public static SqlConnection Connection;
    }
}