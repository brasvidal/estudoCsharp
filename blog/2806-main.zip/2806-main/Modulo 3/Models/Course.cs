using System;

namespace BaltaDataAccess.Models
{
    public class Course
    {
        public Guid Id { get; set; }
        public string Title { get; set; }
    }
}