### dotnet CLI

#### Verificando versão atual instalada

#### Listando versões instaladas

#### Alterando Versões

#### Aceitando os certificados
